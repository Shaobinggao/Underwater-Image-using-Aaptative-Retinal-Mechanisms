-----------COPYRIGHT NOTICE STARTS WITH THIS LINE------------
Copyright (c) 2019
All rights reserved. This doucuments are a rough version to summarize the results in publication [1],
which is available only for research purpose.

We preserve the rights to further correct and update the data.

The data contains both the original image and the ehnanced image by our porposed Aaptative Retinal Mechanisms (ASM) based mehtod 
on various datasets. All of the images are from the internet or provided by the author corresponding to publications citeted in [1].
Please also cite these papers if you use the results presented here.

If you use this data for the evaluation and comparison of your approach, please
cite our work as follows:

[1] Gao, S. B., Zhang, M., Zhao, Q., Zhang, X. S., & Li, Y. J. (2019). Underwater image enhancement using adaptive retinal mechanisms. 
IEEE Transactions on Image Processing, 28(11), 5580-5595.

Any questions��comments or the request for more results in paper are welcome to gaoshaobing@scu.edu.cn